function [output] = output_function(x)
    % set output here
    output = x;
end
