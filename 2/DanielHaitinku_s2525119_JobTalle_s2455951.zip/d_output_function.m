function [ output ] = d_output_function( x )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    output = 1;

end

